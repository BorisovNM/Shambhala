harmony.afx <- function(x,
                     K=10,
                     L=4,
                     p1.names=0,
                     p2.names=0,
                     gene.cluster="skmeans",
                     assay.cluster="hclust",
                     corr="pearson",
                     iterations=1,
                     skip.match=FALSE,
                     is.assays.identical=FALSE,
                     output.iterations=FALSE) {
  harmony.result <- harmony(
    x,
    XPN.AFX.RDA,
    K,
    L,
    p1.names,
    p2.names,
    gene.cluster,
    assay.cluster,
    corr,
    iterations,
    skip.match,
    is.assays.identical,
    output.iterations)
  
  x.vector <- as.vector(as.matrix(harmony.result$x))
  y.vector <- as.vector(as.matrix(XPN.AFX.RDA))
  x.mean <- mean(x.vector)
  y.mean <- mean(y.vector)
  x.sd <- sd(x.vector)
  y.sd <- sd(y.vector)
  
  return (as.matrix((harmony.result$x - x.mean) / x.sd * y.sd + y.mean))
}

harmony.afx.static <- function(x,
                     K=10,
                     L=4,
                     p1.names=0,
                     p2.names=0,
                     gene.cluster="skmeans",
                     assay.cluster="hclust",
                     corr="pearson",
                     iterations=1,
                     skip.match=FALSE,
                     is.assays.identical=FALSE,
                     output.iterations=FALSE) {
  harmony.result <- harmony.static(
    x,
    XPN.AFX.RDA,
    K,
    L,
    p1.names,
    p2.names,
    gene.cluster,
    assay.cluster,
    corr,
    iterations,
    skip.match,
    is.assays.identical,
    output.iterations)
  
  x.vector <- as.vector(as.matrix(harmony.result$x))
  y.vector <- as.vector(as.matrix(XPN.AFX.RDA))
  x.mean <- mean(x.vector)
  y.mean <- mean(y.vector)
  x.sd <- sd(x.vector)
  y.sd <- sd(y.vector)
  
  return (as.matrix((harmony.result$x - x.mean) / x.sd * y.sd + y.mean))
}

harmony.afx.equi <- function(x,
                     K=10,
                     L=4,
                     p1.names=0,
                     p2.names=0,
                     gene.cluster="skmeans",
                     assay.cluster="hclust",
                     corr="pearson",
                     iterations=1,
                     skip.match=FALSE,
                     is.assays.identical=FALSE,
                     output.iterations=FALSE) {
  harmony.result <- harmony.equi(
    x,
    XPN.AFX.RDA,
    K,
    L,
    p1.names,
    p2.names,
    gene.cluster,
    assay.cluster,
    corr,
    iterations,
    skip.match,
    is.assays.identical,
    output.iterations)
  
  x.vector <- as.vector(as.matrix(harmony.result$x))
  y.vector <- as.vector(as.matrix(XPN.AFX.RDA))
  x.mean <- mean(x.vector)
  y.mean <- mean(y.vector)
  x.sd <- sd(x.vector)
  y.sd <- sd(y.vector)
  
  return (as.matrix((harmony.result$x - x.mean) / x.sd * y.sd + y.mean))
}

harmony.afx.static.equi <- function(x,
                     K=10,
                     L=4,
                     p1.names=0,
                     p2.names=0,
                     gene.cluster="skmeans",
                     assay.cluster="hclust",
                     corr="pearson",
                     iterations=1,
                     skip.match=FALSE,
                     is.assays.identical=FALSE,
                     output.iterations=FALSE) {
  harmony.result <- harmony.static.equi(
    x,
    XPN.AFX.RDA,
    K,
    L,
    p1.names,
    p2.names,
    gene.cluster,
    assay.cluster,
    corr,
    iterations,
    skip.match,
    is.assays.identical,
    output.iterations)
  
  x.vector <- as.vector(as.matrix(harmony.result$x))
  y.vector <- as.vector(as.matrix(XPN.AFX.RDA))
  x.mean <- mean(x.vector)
  y.mean <- mean(y.vector)
  x.sd <- sd(x.vector)
  y.sd <- sd(y.vector)
  
  return (as.matrix((harmony.result$x - x.mean) / x.sd * y.sd + y.mean))
}

