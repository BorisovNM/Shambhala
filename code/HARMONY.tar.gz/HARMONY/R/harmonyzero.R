harmony.zero <- function(x,
                     y,
                     zero.x,
                     zero.y,
                     K=10,
                     L=4,
                     p1.names=0,
                     p2.names=0,
                     gene.cluster="kmeans",
                     assay.cluster="kmeans",
                     corr="pearson",
                     iterations=30,
                     skip.match=FALSE,
                     is.assays.identical=FALSE,
                     output.iterations=FALSE,
                     cross.platform.zeros=TRUE) {
  n.samples <- ncol(x)
  if (n.samples != ncol(y))
    stop("ncol(x) != ncol(y)")
  
  genes <- intersect(rownames(x), rownames(y))
  x <- x[genes,]
  y <- y[genes,]
  
  x.is.non.zero <- t(t(x) < zero.x)
  y.is.non.zero <- t(t(y) < zero.y)
  
  if (cross.platform.zeros) {
    all.zero.genes <- intersect(
      names(which(apply(x.is.non.zero, 1, all))),
      names(which(apply(y.is.non.zero, 1, all)))
    )
  } else {
    all.zero.genes <- union(
      names(which(apply(x.is.non.zero, 1, all))),
      names(which(apply(y.is.non.zero, 1, all)))
    )
  }
  
  non.zero.genes <- setdiff(genes, all.zero.genes)
  
  marker.gene <- NULL
  if (length(all.zero.genes) > 0) {
    marker.gene <- all.zero.genes[1]
    
    x[marker.gene, ] <- apply(x[all.zero.genes, ], 2, median)
    y[marker.gene, ] <- apply(y[all.zero.genes, ], 2, median)
    
    all.zero.genes <- setdiff(all.zero.genes, c(marker.gene))
    non.zero.genes <- c(non.zero.genes, marker.gene)
  }
  
  cat (sprintf(
    "Genes: all zeros = %d, non zeros = %d, total = %d\n",
    length(all.zero.genes), length(non.zero.genes), length(genes)))
  
  harmony.result <- harmony(
    x[non.zero.genes,],
    y[non.zero.genes,],
    K,
    L,
    p1.names,
    p2.names,
    gene.cluster,
    assay.cluster,
    corr,
    iterations,
    skip.match,
    is.assays.identical,
    output.iterations)
  
  zero.matrix.x <- matrix(ncol = n.samples, nrow = 0)
  zero.matrix.y <- matrix(ncol = n.samples, nrow = 0)
  if (!is.null(marker.gene)) {
    harmony.result$x[marker.gene,] <- median(unlist(harmony.result$x[marker.gene,]))
    zero.matrix.x <- as.matrix(harmony.result$x[rep(marker.gene, length(all.zero.genes)),])
    rownames(zero.matrix.x) <- all.zero.genes
    colnames(zero.matrix.x) <- colnames(x)
    
    harmony.result$y[marker.gene,] <- median(unlist(harmony.result$y[marker.gene,]))
    zero.matrix.y <- as.matrix(harmony.result$y[rep(marker.gene, length(all.zero.genes)),])
    rownames(zero.matrix.y) <- all.zero.genes
    colnames(zero.matrix.y) <- colnames(y)
  }
  
  harmony.result$x <- rbind(harmony.result$x, zero.matrix.x)
  harmony.result$y <- rbind(harmony.result$y, zero.matrix.y)
  
  if (output.iterations) {
    niteration <- length(harmony.result$iterations)
    for (index in 1:niteration) {
      harmony.result$iterations[[index]]$x <- rbind(harmony.result$iterations[[index]]$x, zero.matrix.x)
      harmony.result$iterations[[index]]$y <- rbind(harmony.result$iterations[[index]]$y, zero.matrix.y)
    }
  }
  
  return (harmony.result)
}
